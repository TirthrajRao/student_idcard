<?php

namespace Picqer\Barcode\Exceptions;

class InvalidLengthException extends BarcodeException {}